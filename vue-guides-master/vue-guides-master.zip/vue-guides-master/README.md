# vue-guides
Official vue-tutorial and code created during recording sessions. This course contains all the completed projects:

- Notemaster
- Starbase
- Starbase-Router
- Jokester
- Turnout

***

Find the original course here: https://www.udemy.com/vue-web-apps/
