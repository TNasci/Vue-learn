export const INIT_JOKES = 'INIT_JOKES'
export const ADD_JOKE = 'ADD_JOKE'
export const REMOVE_JOKE = 'REMOVE_JOKE'
